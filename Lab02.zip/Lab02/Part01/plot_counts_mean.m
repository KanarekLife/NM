function plot_counts_mean(counts_mean)
    plot(counts_mean)
    title 'Średnia liczba losowań na koło'
    xlabel 'Koło'
    ylabel 'Średnia liczba losowań'
end