function plot_circle_areas(circle_areas)
    plot(circle_areas)
    title 'Suma skumulowana pól kół'
    xlabel 'Koło'
    ylabel 'Suma'
end