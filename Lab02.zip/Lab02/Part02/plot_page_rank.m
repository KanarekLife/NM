function plot_page_rank(r)
    bar(r)
    title 'PageRank'
    xlabel 'Strona'
    ylabel 'Wskaźnik PageRank'
end