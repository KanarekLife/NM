[numer_indeksu, Edges, I, B, A, b, r] = page_rank();
plot_page_rank(r);
print -dpng zadanie7.png